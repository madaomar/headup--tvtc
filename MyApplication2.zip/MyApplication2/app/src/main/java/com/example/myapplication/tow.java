package com.example.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import  android.view.View;
import android.content.Intent;


public class tow extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tow);
    }
    public void go_tow(View view) {
        Intent e = new Intent(this, countertow.class);
        startActivity(e);
    }
}
