package com.example.myapplication;

        import android.content.Intent;
        import android.os.Bundle;
        import android.support.v7.app.AppCompatActivity;
        import android.view.View;

public class first extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first);

    }
    public void one(View view) {
        Intent i = new Intent(this, go.class);
        startActivity(i);
    }

    public void tow(View view) {
        Intent i = new Intent(this, tow.class);
        startActivity(i);
    }

    public void three(View view) {
        Intent i = new Intent(this, three_imge.class);
        startActivity(i);

    }

    public void four(View view) {
        Intent i = new Intent(this, four.class);
        startActivity(i);
    }
}


