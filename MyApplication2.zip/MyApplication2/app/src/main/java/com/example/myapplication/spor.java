package com.example.myapplication;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.TextSwitcher;
import android.widget.TextView;
import android.widget.ViewSwitcher;
public class spor extends AppCompatActivity {
    TextSwitcher textSwitcherthree ;
    Button Nextthree ;
    Button pas;
    int counter = 0;

    TextView tvCounter;
    int StringIndex = 0 ;
    String[] Row = {
            "الشطرنج.",
            "السباحة",
            "كرة السلة.",
            "تسلق الجبال",
            "الكرة الطائرة",
            "التنس",
            "كرة القدم.",
            "القولف",
            "الجري",
            "سباق السيارات"
    };
    TextView textViewthree ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_spor);
        tvCounter = findViewById(R.id.zero);
        textSwitcherthree = (TextSwitcher) findViewById(R.id.text_three);
        Nextthree = (Button) findViewById(R.id.button1);
        pas = (Button) findViewById(R.id.button2);

        Nextthree.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                counter++;
                if (counter>= 10) {
                    counter= 0;
                }
                display(counter);

                if (StringIndex == Row.length - 1) {

                    StringIndex = 0;

                    textSwitcherthree.setText(Row[StringIndex]);
                } else {

                    textSwitcherthree.setText(Row[++StringIndex]);
                }
            }
            public void display(int number) {
                TextView quantityTextView = (TextView) findViewById(R.id.zero);
                quantityTextView.setText("" + number);
            }



        });

        textSwitcherthree.setFactory(new ViewSwitcher.ViewFactory() {

            @Override
            public View makeView() {
                textViewthree = new TextView(spor.this);
                textViewthree.setTextColor(Color.BLACK);
                textViewthree.setTextSize(40);
                textViewthree.setGravity(Gravity.CENTER_HORIZONTAL);
                return textViewthree;
            }

        });

        textSwitcherthree.setText(Row[StringIndex]);
        pas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                counter--;
                if (counter>=0) {
                    display(counter);
                }
                if (StringIndex == Row.length - 1) {

                    StringIndex = 0;

                    textSwitcherthree.setText(Row[StringIndex]);
                } else {

                    textSwitcherthree.setText(Row[++StringIndex]);
                }
            }
                public void display(int number) {
                    TextView quantityTextView = (TextView) findViewById(R.id.zero);
                    quantityTextView.setText("" + number);
            }

        });
    }

        public void langu(View view) {
            Intent f = new Intent(this, first.class);
            startActivity(f);
            }
        }
