package com.example.myapplication;


import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.View;
import android.widget.Button;
import android.widget.TextSwitcher;
import android.widget.TextView;
import android.widget.ViewSwitcher;



public class mark extends AppCompatActivity {

    TextSwitcher textSwitcher;
    Button Next;
    TextView tvCounter;
    int counter = 0;
    Button pass;
    int StringIndex = 0;
    String[] Row = {
            "كودو",
            "البيك",
            "Chanel",
            "اديداس",
            "سيفورا",
            "هواوي",
            "أبل",
            "مكياجي",
            "ماكدونالدز",
            "Dior"
    };

    TextView textView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mark);
        tvCounter = findViewById(R.id.zero);
        textSwitcher = (TextSwitcher) findViewById(R.id.textswitcher1);
        Next = (Button) findViewById(R.id.button3);
        pass = (Button) findViewById(R.id.button4);


        Next.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {
                counter++;
                if (counter >= 10) {
                    counter = 0;
                }
                display(counter);

                if (StringIndex == Row.length - 1) {

                    StringIndex = 0;

                    textSwitcher.setText(Row[StringIndex]);
                } else {

                    textSwitcher.setText(Row[++StringIndex]);
                }

            }

            public void display(int number) {
                TextView quantityTextView = (TextView) findViewById(R.id.zero);
                quantityTextView.setText("" + number);
            }
        });

        textSwitcher.setFactory(new ViewSwitcher.ViewFactory() {

            @Override
            public View makeView() {

                textView = new TextView(mark.this);
                textView.setTextColor(Color.BLACK);
                textView.setTextSize(40);
                textView.setGravity(Gravity.CENTER_HORIZONTAL);
                return textView;

            }
        });

        textSwitcher.setText(Row[StringIndex]);

        pass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                counter--;
                if (counter >= 0) {
                    display(counter);
                }


                if (StringIndex == Row.length - 1) {

                    StringIndex = 0;

                    textSwitcher.setText(Row[StringIndex]);
                } else {

                    textSwitcher.setText(Row[++StringIndex]);
                }


            }

            public void display(int number) {
                TextView quantityTextView = (TextView) findViewById(R.id.zero);
                quantityTextView.setText("" + number);
            }
        });
    }
        public void langu (View view){
            Intent f = new Intent(this, first.class);
            startActivity(f);
        }
    }

