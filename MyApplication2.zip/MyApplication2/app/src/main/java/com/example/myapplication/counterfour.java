package com.example.myapplication;

import android.annotation.TargetApi;
import android.content.Intent;
import android.os.Build;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class counterfour extends AppCompatActivity {
    public int counter;

    @TargetApi(Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_counterfour);
        final TextView countt = findViewById(R.id.countt);
        new CountDownTimer(+5000, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                countt.setText(String.valueOf(counter));
                counter++;
            }

            @Override
            public void onFinish() {
                countt.setText("هيا بنا ");
            }
        }.start();
    }

    public void fam(View view) {
        Intent f = new Intent(this, famous.class);
        startActivity(f);
    }
}


