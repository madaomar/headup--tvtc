package com.example.myapplication;

import android.annotation.TargetApi;
import android.content.Intent;
import android.os.Build;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class count extends AppCompatActivity {

    public int counter;

    @TargetApi(Build.VERSION_CODES.O)

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_count);
        final TextView counttime = findViewById(R.id.counttime);
        new CountDownTimer(+5000 , 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                counttime.setText(String.valueOf(counter));
                counter++;
            }

            @Override
            public void onFinish() {
                counttime.setText("هيا بنا ");
            }
        }.start();
    }

    public void mar(View view) {
        Intent y = new Intent(this, mark.class);
        startActivity(y);
    }
}



