package com.example.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import  android.view.View;
import android.content.Intent;

public class go extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_go);
    }
    public void go(View view) {
        Intent x= new Intent(this, count.class);
        startActivity(x);
    }
}