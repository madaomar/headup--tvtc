package com.example.myapplication;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.TextSwitcher;
import android.widget.TextView;
import android.widget.ViewSwitcher;

public class lang extends AppCompatActivity {
    TextSwitcher textSwitchertow ;
    Button Nexttow ;
    Button passs;
    TextView tvCounter;

    int counter = 0;

    int StringIndex = 0 ;
    String[] Row = {
            "Gracias",
            "congratulations",
            "Pardon",
            "günaydın",
            "Buenas tardes",
            "사랑해요",
            "hello",
            "안녕하세요",
            "Hola",
            "Nasılsını"
    };

    TextView textViewtow ;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lang);
        textSwitchertow = (TextSwitcher)findViewById(R.id.text_tow);
        tvCounter = findViewById(R.id.zero);

        Nexttow = (Button)findViewById(R.id.button5);
        passs = (Button)findViewById(R.id.button6);
        Nexttow.setOnClickListener(new View.OnClickListener() {

                public void onClick(View arg0) {
                    counter++;
                    if (counter>= 10) {
                        counter= 0;
                    }
                    display(counter);
                    if (StringIndex == Row.length - 1) {

                        StringIndex = 0;

                        textSwitchertow.setText(Row[StringIndex]);
                    } else {

                        textSwitchertow.setText(Row[++StringIndex]);
                    }
                }
                    public void display(int number) {
                        TextView quantityTextView = (TextView) findViewById(R.id.zero);
                        quantityTextView.setText("" + number);
                    }

        });

        textSwitchertow.setFactory(new ViewSwitcher.ViewFactory(){

            @Override
            public View makeView() {

                textViewtow = new TextView(lang.this);
                textViewtow.setTextColor(Color.BLACK);
                textViewtow.setTextSize(40);
                textViewtow.setGravity(Gravity.CENTER_HORIZONTAL);
                return textViewtow;


                }
            });

        textSwitchertow.setText(Row[StringIndex]);
passs.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View arg0) {
                    counter--;
                    if (counter>=0) {
                        display(counter);
                    }
                    if (StringIndex == Row.length - 1) {

                        StringIndex = 0;

                        textSwitchertow.setText(Row[StringIndex]);
                    } else {

                        textSwitchertow.setText(Row[++StringIndex]);
                    }

                }
    public void display(int number) {
        TextView quantityTextView = (TextView) findViewById(R.id.zero);
        quantityTextView.setText("" + number);
    }
});


    }
    public void langu(View view) {
        Intent f = new Intent(this, first.class);
        startActivity(f);
    }
}

