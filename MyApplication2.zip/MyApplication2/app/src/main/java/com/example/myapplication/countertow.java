package com.example.myapplication;

import android.annotation.TargetApi;
import android.content.Intent;
import android.os.Build;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class countertow extends AppCompatActivity {
    public int counterr;

    @TargetApi(Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_countertow);
        final TextView tow_cont = findViewById(R.id.tow_cont );
        new CountDownTimer(+5000, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                tow_cont.setText(String.valueOf(counterr));
                counterr++;
            }

            @Override
            public void onFinish() {
                tow_cont.setText("هيا بنا ");
            }
        }.start();
    }

    public void lag(View view) {
        Intent l = new Intent(this, spor.class);
        startActivity(l);
    }
}

